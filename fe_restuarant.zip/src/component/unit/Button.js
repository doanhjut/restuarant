import React from 'react'

function Button() {
    return (
        <div className='button-animation'>
            <div className="wrap">
                <button className="button">Submit</button>
            </div>
        </div>
    )
}

export default Button
