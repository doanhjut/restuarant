import Introduce from "./component/Introduce";
import Comment from "./component/Comment";
import ImageHover from "../unit/ImageHover"
function IntroduceIndex() {
  return (
    <div className="App">
        <Introduce></Introduce>
        <ImageHover></ImageHover>
    </div>
  );
}

export default IntroduceIndex;
