import Book from "./component/Book"
function BookIndex() {
  return (
    <div className="App">
        <Book></Book>
    </div>
  );
}

export default BookIndex;
