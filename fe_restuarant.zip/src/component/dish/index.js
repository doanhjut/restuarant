import Dish from "./component/Dish"
function DishIndex() {
  return (
    <div className="App">
        <Dish></Dish>
    </div>
  );
}

export default DishIndex;
