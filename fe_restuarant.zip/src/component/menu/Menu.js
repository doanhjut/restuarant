import React from 'react'
import './menu.css'
function Menu() {
    return (
        <div className='menu'>
            <nav>
                <a href="#">Trang chủ</a>
                <a href="#">Menu</a>
                <a href="#">Đặt bàn</a>
                <a href="#">Địa chỉ</a>
                <a href="#">Liên hệ</a>
                <div class="animation start-home"></div>
            </nav>
        </div>
    )
}

export default Menu
