import {combineReducers} from 'redux'
import dataTable from './dataTable'
 
export default combineReducers({
    dataTable: dataTable
})